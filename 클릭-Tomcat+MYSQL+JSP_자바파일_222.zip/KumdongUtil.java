package KumdongUtil;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.SimpleTimeZone;

public class KumdongUtil
{
  public static String getAfterDay(String paramString, long paramLong)
    throws Exception
  {
    Calendar localCalendar1 = Calendar.getInstance();
    Calendar localCalendar2 = Calendar.getInstance();
    Date localDate = new Date();

    Object localObject = null;
    String str1 = null;
    String str2 = null;

    localCalendar1.set(Integer.parseInt(paramString.substring(0, 4)), Integer.parseInt(paramString.substring(4, 6)) - 1, Integer.parseInt(paramString.substring(6)));

    long l = localCalendar1.getTime().getTime() + paramLong * 86400000L;

    localDate.setTime(l);
    localCalendar2.setTime(localDate);

    if (localCalendar2.get(2) + 1 < 10)
      str1 = "0" + new Integer(localCalendar2.get(2) + 1).toString();
    else {
      str1 = new Integer(localCalendar2.get(2) + 1).toString();
    }

    if (localCalendar2.get(5) < 10)
      str2 = "0" + new Integer(localCalendar2.get(5)).toString();
    else {
      str2 = new Integer(localCalendar2.get(5)).toString();
    }

    return new Integer(localCalendar2.get(1)).toString() + str1 + str2;
  }

  public static String nullcheck(String paramString)
    throws Exception
  {
    if (paramString == null) {
      return "";
    }
    return paramString;
  }

  public static String nullcheck2(String paramString)
    throws Exception
  {
    paramString = nullcheck(paramString);

    if (paramString.equals("null")) {
      return "";
    }
    return paramString;
  }

  public static String nullcheck3(String paramString)
    throws Exception
  {
    paramString = nullcheck(paramString);

    if ((paramString.equals("null")) || ("".equals(paramString)) || (paramString.equals("Null")) || (paramString.equals("NULL"))) {
      return "&nbsp;";
    }
    return paramString;
  }

  public static String zero2nbsp(int paramInt)
    throws Exception
  {
    if (paramInt == 0) {
      return "&nbsp;";
    }
    return Integer.toString(paramInt);
  }

  public static String dbTxt2kor(String paramString)
    throws UnsupportedEncodingException
  {
    if (paramString == null) return null;
    return new String(paramString.getBytes("KSC5601"), "8859_1");
  }

  public static String kor2Db(String paramString)
    throws UnsupportedEncodingException
  {
    if (paramString == null) return null;
    return new String(paramString.getBytes("8859_1"), "KSC5601");
  }

  public static String kor2nextPage(String paramString)
    throws UnsupportedEncodingException
  {
    return kor2Db(paramString);
  }

  public static String replaceChar(String paramString1, String paramString2, String paramString3)
  {
    String str = "";

    for (int i = 0; i < paramString1.length(); ++i) {
      if (String.valueOf(paramString1.charAt(i)).equals(paramString2))
        str = str + paramString3;
      else str = str + String.valueOf(paramString1.charAt(i));
    }
    return str;
  }

  public static String repToDb(String paramString)
  {
    return replaceChar(paramString, "'", "''");
  }

  public static String sq4Alert(String paramString)
  {
    String str = "";

    if (paramString == null) return null;

    for (int i = 0; i < paramString.length(); ++i) {
      if (paramString.charAt(i) == '\'')
        str = str + "\\'";
      else if (paramString.charAt(i) == '\n')
        str = str + "";
      else {
        str = str + String.valueOf(paramString.charAt(i));
      }
    }
    return str;
  }

  public static String getDateFormatString(String paramString)
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat(paramString, Locale.KOREA);
    String str = localSimpleDateFormat.format(new Date());
    return str;
  }

  public static void filecreate(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    try
    {
      String str1 = getDateFormatString("yyyy-MM-dd HH:mm:ss");
      String str2 = "/usr/local/log/error.txt";
      if ("".equals(paramString3)) paramString3 = "No_Data3";
      if ("".equals(paramString4)) paramString4 = "No_Data4";
      String str3 = "error log--\n" + str1 + "->Error_Message1:" + paramString1 + "->Error_Message2 :" + paramString2 + "->Error_Message3 :" + paramString3 + "->Error_Message4 :" + paramString4 + "\n";

      FileWriter localFileWriter = new FileWriter(str2, true);

      localFileWriter.write(kor2Db(str3));
      localFileWriter.close();
    } catch (IOException localIOException) {
      localIOException.printStackTrace();
    }
  }

  public static void message_log(String paramString)
  {
    try
    {
      Object localObject;
      String str1 = getDateFormatString("yyyyMMdd");
      String str2 = "c:/log/" + str1;

      String str3 = "Error_Message1:" + paramString + "\n";

      if (isFileExists(str2))
      {
        localObject = new FileWriter(str2, true);

        ((FileWriter)localObject).write(str3);
        ((FileWriter)localObject).close();
      } else {
        localObject = new BufferedWriter(new FileWriter(str2));
        ((BufferedWriter)localObject).write(str3, 0, str3.length());
        ((BufferedWriter)localObject).flush();
        ((BufferedWriter)localObject).close();

        FileWriter localFileWriter = new FileWriter(str2, true);

        localFileWriter.write(str3);
        localFileWriter.close();
      }
    } catch (IOException localIOException) {
      localIOException.printStackTrace();
    }
  }

  public static boolean isFileExists(String paramString)
  {
    File localFile = new File(paramString);

    return (!(localFile.exists()));
  }

  public static String dbTxt2html(String paramString)
  {
    String str = "";
    if (paramString == null) return null;
    for (int i = 0; i < paramString.length(); ++i) {
      if (paramString.charAt(i) == '\n')
        str = str + "<br>";
      else if (paramString.charAt(i) == ' ')
        str = str + "&nbsp;";
      else {
        str = str + String.valueOf(paramString.charAt(i));
      }
    }
    return str;
  }

  public static String txtNum2comma(String paramString)
  {
    int i = 0;
    int j = 0;
    String str = "";
    if ("-".equals(paramString.substring(0, 1))) {
      str = "-";
      paramString = paramString.substring(1);
    }
    i = paramString.length();
    j = i - 3;
    while (j > 0) {
      paramString = paramString.substring(0, j) + ',' + paramString.substring(j);
      j -= 3;
    }
    if ("-".equals(str))
      paramString = "-" + paramString;
    return paramString;
  }

  public static String intNum2comma(int paramInt)
  {
    String str = String.valueOf(paramInt);
    int i = 0;
    int j = 0;
    i = str.length();
    j = i - 3;
    while (j > 0) {
      str = str.substring(0, j) + ',' + str.substring(j);
      j -= 3;
    }
    return str;
  }

  public static String longNum2comma(long paramLong)
  {
    String str1 = String.valueOf(paramLong);
    int i = 0;
    int j = 0;
    String str2 = "";
    if ("-".equals(str1.substring(0, 1))) {
      str2 = "-";
      str1 = str1.substring(1);
    }
    i = str1.length();
    j = i - 3;
    while (j > 0) {
      str1 = str1.substring(0, j) + ',' + str1.substring(j);
      j -= 3;
    }
    if ("-".equals(str2))
      str1 = "-" + str1;
    return str1;
  }

  public static String txt2bar(String paramString, int paramInt)
  {
    int i = 0;
    int j = 0;
    i = paramString.length();
    j = i - paramInt;
    while (j > 0) {
      paramString = paramString.substring(0, j) + '-' + paramString.substring(j);
      j -= 4;
    }
    return paramString;
  }

  public static String thisYear()
    throws Exception
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy", Locale.KOREA);
    Date localDate = new Date();
    String str = localSimpleDateFormat.format(localDate);
    return str;
  }

  public static String thisMonth()
    throws Exception
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("MM", Locale.KOREA);
    Date localDate = new Date();
    String str = localSimpleDateFormat.format(localDate);
    return str;
  }

  public static String thisDay()
    throws Exception
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("dd", Locale.KOREA);
    Date localDate = new Date();
    String str = localSimpleDateFormat.format(localDate);
    return str;
  }

  public static String nowDate()
    throws Exception
  {
    return thisYear() + thisMonth() + thisDay();
  }

  public static String nowTime()
    throws Exception
  {
    SimpleTimeZone localSimpleTimeZone = new SimpleTimeZone(32400000, "Asia/Seoul");

    GregorianCalendar localGregorianCalendar = new GregorianCalendar(localSimpleTimeZone);
    Date localDate = new Date();
    localGregorianCalendar.setTime(localDate);

    if (localGregorianCalendar.get(10) < 10) {
      return "0" + String.valueOf(localGregorianCalendar.get(10) * 100 + localGregorianCalendar.get(12));
    }
    return String.valueOf(localGregorianCalendar.get(10) * 100 + localGregorianCalendar.get(12));
  }
}